// VoiceBridge - JavaScript for Accessibility and TTS Functionality

class VoiceBridge {
    constructor() {
        this.speechSynthesis = window.speechSynthesis;
        this.currentUtterance = null;
        this.isHoverSpeakEnabled = true;
        this.hoverDelay = 300;
        this.hoverTimeout = null;
        this.uploadedFiles = [];
        this.currentAudio = null;
        this.settings = this.loadSettings();
        this.isAudioPlaybackActive = false;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadVoices();
        this.applySettings();
        this.setupKeyboardNavigation();
        this.setupFileUpload();
        this.setupAudioPlayer();
        this.setupHoverToSpeak();
        this.unlockSpeechOnFirstGesture();
    }

    // Settings Management
    loadSettings() {
        const defaultSettings = {
            voice: 'default',
            rate: 1.0,
            pitch: 1.0,
            volume: 1.0,
            fontSize: 16,
            darkMode: false,
            highContrast: false,
            hoverSpeak: true,
            hoverDelay: 300
        };

        try {
            const saved = localStorage.getItem('voicebridge-settings');
            return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
        } catch (error) {
            console.warn('Failed to load settings:', error);
            return defaultSettings;
        }
    }

    saveSettings() {
        try {
            localStorage.setItem('voicebridge-settings', JSON.stringify(this.settings));
        } catch (error) {
            console.warn('Failed to save settings:', error);
        }
    }

    applySettings() {
        // Apply font size
        document.documentElement.style.fontSize = `${this.settings.fontSize}px`;
        
        // Apply theme
        if (this.settings.highContrast) {
            document.documentElement.setAttribute('data-theme', 'high-contrast');
        } else if (this.settings.darkMode) {
            document.documentElement.setAttribute('data-theme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
        }

        // Update settings UI
        this.updateSettingsUI();
    }

    updateSettingsUI() {
        const elements = {
            voiceSelect: this.settings.voice,
            rateSlider: this.settings.rate,
            pitchSlider: this.settings.pitch,
            volumeSlider: this.settings.volume,
            fontSizeSlider: this.settings.fontSize,
            darkModeToggle: this.settings.darkMode,
            highContrastToggle: this.settings.highContrast,
            hoverSpeakToggle: this.settings.hoverSpeak,
            hoverDelaySlider: this.settings.hoverDelay
        };

        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = value;
                } else if (element.type === 'range') {
                    element.value = value;
                    this.updateSliderValue(id, value);
                } else {
                    element.value = value;
                }
            }
        });
    }

    // Event Listeners Setup
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateToSection(link.getAttribute('href').substring(1));
            });
        });

        // Settings controls
        this.setupSettingsListeners();
    }

    setupSettingsListeners() {
        // Voice settings
        const voiceSelect = document.getElementById('voiceSelect');
        if (voiceSelect) {
            voiceSelect.addEventListener('change', (e) => {
                this.settings.voice = e.target.value;
                this.saveSettings();
            });
        }

        // Sliders
        const sliders = ['rateSlider', 'pitchSlider', 'volumeSlider', 'fontSizeSlider', 'hoverDelaySlider'];
        sliders.forEach(sliderId => {
            const slider = document.getElementById(sliderId);
            if (slider) {
                slider.addEventListener('input', (e) => {
                    const value = parseFloat(e.target.value);
                    this.settings[sliderId.replace('Slider', '')] = value;
                    this.updateSliderValue(sliderId, value);
                    this.saveSettings();
                    this.applySettings();

                    // Apply volume live to current audio
                    if (sliderId === 'volumeSlider' && this.currentAudio) {
                        this.currentAudio.volume = Math.min(1, Math.max(0, value));
                        if (value === 0) {
                            this.showNotification('Volume is set to 0. Increase to hear audio.', 'error');
                        }
                    }
                });
            }
        });

        // Toggles
        const toggles = ['darkModeToggle', 'highContrastToggle', 'hoverSpeakToggle'];
        toggles.forEach(toggleId => {
            const toggle = document.getElementById(toggleId);
            if (toggle) {
                toggle.addEventListener('change', (e) => {
                    const settingName = toggleId.replace('Toggle', '');
                    this.settings[settingName] = e.target.checked;
                    this.saveSettings();
                    this.applySettings();
                    if (toggleId === 'hoverSpeakToggle' && e.target.checked) {
                        this.speak('Hover to Speak enabled', { allowDuringPlayback: true });
                    }
                });
            }
        });
    }

    updateSliderValue(sliderId, value) {
        const valueElement = document.getElementById(sliderId.replace('Slider', 'Value'));
        if (valueElement) {
            if (sliderId === 'fontSizeSlider') {
                valueElement.textContent = `${value}px`;
            } else if (sliderId === 'hoverDelaySlider') {
                valueElement.textContent = `${value}ms`;
            } else {
                valueElement.textContent = value.toFixed(1);
            }
        }
    }

    // Voice Management
    loadVoices() {
        const populateVoices = () => {
            const voiceSelect = document.getElementById('voiceSelect');
            if (!voiceSelect) return;

            const voices = this.speechSynthesis.getVoices();
            voiceSelect.innerHTML = '<option value="default">Default Voice</option>';

            voices.forEach((voice, index) => {
                const option = document.createElement('option');
                option.value = index;
                option.textContent = `${voice.name} (${voice.lang})`;
                voiceSelect.appendChild(option);
            });
        };

        // Load voices immediately and when they change
        populateVoices();
        this.speechSynthesis.addEventListener('voiceschanged', populateVoices);
    }

    // Speech Synthesis
    speak(text, options = {}) {
        if (!text) return;
        const { allowDuringPlayback = false } = options;

        // If audio is active and we're not explicitly allowed to speak, skip
        if (this.isAudioActive() && !allowDuringPlayback) {
            return;
        }

        // Stop current speech
        this.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        
        // Apply settings (clamped ranges)
        const rate = Number.isFinite(options.rate) ? options.rate : this.settings.rate;
        const pitch = Number.isFinite(options.pitch) ? options.pitch : this.settings.pitch;
        const volume = Number.isFinite(options.volume) ? options.volume : this.settings.volume;
        utterance.rate = Math.min(2, Math.max(0.5, Number(rate) || 1));
        utterance.pitch = Math.min(2, Math.max(0, Number(pitch) || 1));
        utterance.volume = Math.min(1, Math.max(0, Number(volume) || 1));
        utterance.lang = options.lang || 'en-US';

        // Set voice
        if (this.settings.voice !== 'default') {
            const voices = this.speechSynthesis.getVoices();
            const selectedVoice = voices[parseInt(this.settings.voice)];
            if (selectedVoice) {
                utterance.voice = selectedVoice;
            }
        }

        // Event handlers
        utterance.onstart = () => {
            this.currentUtterance = utterance;
            // If we're allowed to speak during playback, temporarily pause audio
            if (allowDuringPlayback && this.currentAudio && !this.currentAudio.paused) {
                try { this.currentAudio.pause(); } catch (_) {}
            }
        };

        utterance.onend = () => {
            this.currentUtterance = null;
            // Resume audio if we paused it for hover speak
            if (allowDuringPlayback && this.currentAudio && this.currentAudio.paused && !this.currentAudio.ended) {
                const p = this.currentAudio.play();
                if (p && typeof p.catch === 'function') {
                    p.catch(() => {});
                }
            }
        };

        utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event.error);
            this.showNotification('Speech synthesis error: ' + event.error, 'error');
        };

        this.speechSynthesis.speak(utterance);
    }

    isAudioActive() {
        return (
            this.currentAudio &&
            !this.currentAudio.paused &&
            !this.currentAudio.ended &&
            this.currentAudio.readyState >= 2
        );
    }

    stopSpeaking() {
        this.speechSynthesis.cancel();
        this.currentUtterance = null;
    }

    // Hover-to-Speak
    setupHoverToSpeak() {
        const elements = document.querySelectorAll('[data-speak]');
        
        elements.forEach(element => {
            element.addEventListener('mouseenter', (e) => {
                if (!this.settings.hoverSpeak) return;
                
                clearTimeout(this.hoverTimeout);
                this.hoverTimeout = setTimeout(() => {
                    const text = e.target.getAttribute('data-speak');
                    if (text) {
                        this.speak(text, { allowDuringPlayback: true });
                    }
                }, this.settings.hoverDelay);
            });

            element.addEventListener('mouseleave', () => {
                clearTimeout(this.hoverTimeout);
            });

            element.addEventListener('focus', (e) => {
                if (!this.settings.hoverSpeak) return;
                
                const text = e.target.getAttribute('data-speak');
                if (text) {
                    this.speak(text, { allowDuringPlayback: true });
                }
            });

            // Also announce on click to satisfy user gesture requirements
            element.addEventListener('click', (e) => {
                if (!this.settings.hoverSpeak) return;
                const text = e.currentTarget.getAttribute('data-speak');
                if (text) {
                    this.speak(text, { allowDuringPlayback: true });
                }
            });
        });
    }

    // Unlock speech engines after first user gesture
    unlockSpeechOnFirstGesture() {
        const resume = () => {
            try {
                // Some browsers require resume() to unlock queued speech
                if (this.speechSynthesis.paused) this.speechSynthesis.resume();
                // Play a short zero-length utterance to prime engine
                const u = new SpeechSynthesisUtterance('');
                this.speechSynthesis.speak(u);
            } catch (_) {}
            window.removeEventListener('click', resume);
            window.removeEventListener('keydown', resume);
            window.removeEventListener('touchstart', resume);
        };
        window.addEventListener('click', resume, { once: true });
        window.addEventListener('keydown', resume, { once: true });
        window.addEventListener('touchstart', resume, { once: true });
    }

    // Navigation
    navigateToSection(sectionId) {
        // Hide all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        const activeLink = document.querySelector(`[href="#${sectionId}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Announce navigation
        this.speak(`Navigated to ${sectionId.replace('-', ' ')} section`);
    }

    // Keyboard Navigation
    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Tab navigation
            if (e.key === 'Tab') {
                // Let default tab behavior work
                return;
            }

            // Escape key
            if (e.key === 'Escape') {
                this.stopSpeaking();
                this.hideNotification();
            }

            // Arrow keys for navigation
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                this.navigateWithArrows(e.key === 'ArrowDown' ? 1 : -1);
            }

            // Space and Enter for activation
            if (e.key === ' ' || e.key === 'Enter') {
                const focused = document.activeElement;
                if (focused && (focused.tagName === 'BUTTON' || focused.tagName === 'A')) {
                    e.preventDefault();
                    focused.click();
                }
            }
        });
    }

    navigateWithArrows(direction) {
        const focusableElements = document.querySelectorAll(
            'button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        
        const currentIndex = Array.from(focusableElements).indexOf(document.activeElement);
        const nextIndex = currentIndex + direction;
        
        if (nextIndex >= 0 && nextIndex < focusableElements.length) {
            focusableElements[nextIndex].focus();
        }
    }

    // File Upload
    setupFileUpload() {
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const convertBtn = document.getElementById('convertBtn');
        const clearBtn = document.getElementById('clearBtn');

        if (!uploadArea || !fileInput) return;

        // Click to upload
        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
        });

        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            this.handleFiles(e.dataTransfer.files);
        });

        // Convert button
        if (convertBtn) {
            convertBtn.addEventListener('click', () => {
                this.convertFiles();
            });
        }

        // Clear button
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.clearFiles();
            });
        }
    }

    handleFiles(files) {
        Array.from(files).forEach(file => {
            if (this.isValidFile(file)) {
                this.uploadedFiles.push(file);
                this.displayFile(file);
            } else {
                this.showNotification(`Invalid file type: ${file.name}`, 'error');
            }
        });

        this.updateFileControls();
    }

    isValidFile(file) {
        const validTypes = ['text/plain', 'application/pdf'];
        const validExtensions = ['.txt', '.pdf'];
        const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
        
        return validTypes.includes(file.type) || validExtensions.includes(fileExtension);
    }

    displayFile(file) {
        const fileList = document.getElementById('fileList');
        if (!fileList) return;

        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <div class="file-info">
                <i class="fas fa-file-alt file-icon"></i>
                <div class="file-details">
                    <h4>${file.name}</h4>
                    <p>${this.formatFileSize(file.size)}</p>
                </div>
            </div>
            <div class="file-actions">
                <button class="btn btn-control" onclick="voiceBridge.removeFile('${file.name}')" data-speak="Remove file">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;

        fileList.appendChild(fileItem);
    }

    removeFile(fileName) {
        this.uploadedFiles = this.uploadedFiles.filter(file => file.name !== fileName);
        this.updateFileControls();
        this.refreshFileList();
    }

    refreshFileList() {
        const fileList = document.getElementById('fileList');
        if (!fileList) return;

        fileList.innerHTML = '';
        this.uploadedFiles.forEach(file => this.displayFile(file));
    }

    updateFileControls() {
        const convertBtn = document.getElementById('convertBtn');
        const clearBtn = document.getElementById('clearBtn');
        
        const hasFiles = this.uploadedFiles.length > 0;
        
        if (convertBtn) convertBtn.disabled = !hasFiles;
        if (clearBtn) clearBtn.disabled = !hasFiles;
    }

    clearFiles() {
        this.uploadedFiles = [];
        this.refreshFileList();
        this.updateFileControls();
        this.speak('All files cleared');
    }

    async convertFiles() {
        if (this.uploadedFiles.length === 0) return;

        this.showLoading('Converting files to speech...');
        
        try {
            const formData = new FormData();
            this.uploadedFiles.forEach(file => {
                formData.append('files', file);
            });

            const response = await fetch('/api/convert', {
                method: 'POST',
                body: formData
            });

            // If server returned JSON error, surface it
            const contentType = response.headers.get('Content-Type') || '';
            if (!response.ok) {
                if (contentType.includes('application/json')) {
                    const data = await response.json().catch(() => ({}));
                    const msg = data && (data.error || data.message) ? (data.error || data.message) : `HTTP ${response.status}`;
                    throw new Error(msg);
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const audioBlob = await response.blob();
            if (contentType && !contentType.toLowerCase().includes('audio')) {
                // Probably an error payload
                try {
                    const text = await audioBlob.text();
                    throw new Error(text.slice(0, 300));
                } catch (_) {
                    throw new Error('Unexpected server response (not audio).');
                }
            }
            this.playAudio(audioBlob);
            this.showNotification('Files converted successfully!', 'success');
            
        } catch (error) {
            console.error('Conversion error:', error);
            this.showNotification('Failed to convert files: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    // Audio Player
    setupAudioPlayer() {
        this.currentAudio = null;
    }

    playAudio(audioBlob) {
        const audioPlayer = document.getElementById('audioPlayer');
        if (!audioPlayer) return;

        // Create audio URL
        const audioUrl = URL.createObjectURL(audioBlob);
        
        // Create audio element
        if (this.currentAudio) {
            this.currentAudio.pause();
            URL.revokeObjectURL(this.currentAudio.src);
        }

        this.currentAudio = new Audio(audioUrl);
        this.currentAudio.preload = 'metadata';
        this.currentAudio.volume = Math.min(1, Math.max(0, this.settings.volume || 1));
        this.currentAudio.addEventListener('error', () => {
            console.error('Audio element error');
            this.showNotification('Audio failed to load. Please try again.', 'error');
        });
        this.currentAudio.addEventListener('playing', () => {
            this.isAudioPlaybackActive = true;
        });
        this.currentAudio.addEventListener('pause', () => {
            this.isAudioPlaybackActive = false;
        });
        this.currentAudio.addEventListener('ended', () => {
            this.isAudioPlaybackActive = false;
            try {
                if (this.currentAudio && this.currentAudio.src) {
                    URL.revokeObjectURL(this.currentAudio.src);
                }
            } catch (_) {}
        });
        this.setupAudioControls();
        
        // Show player
        audioPlayer.style.display = 'block';
        this.speak('Audio ready to play');

        // Begin playback after we can buffer sufficiently
        const attemptPlay = () => {
            const p = this.currentAudio.play();
            if (p && typeof p.catch === 'function') {
                p.catch(err => {
                    console.warn('Play error:', err);
                });
            }
        };

        const onCanPlayThrough = () => {
            this.currentAudio.removeEventListener('canplaythrough', onCanPlayThrough);
            attemptPlay();
        };

        this.currentAudio.addEventListener('canplaythrough', onCanPlayThrough, { once: true });

        // Fallback: attempt play after short delay (if event doesn't fire)
        setTimeout(() => {
            if (!this.isAudioActive()) {
                attemptPlay();
            }
        }, 500);

        // Handle buffering hiccups
        const retryOnBuffering = () => {
            if (!this.currentAudio) return;
            if (!this.isAudioActive()) {
                attemptPlay();
            }
        };

        this.currentAudio.addEventListener('waiting', retryOnBuffering);
        this.currentAudio.addEventListener('stalled', retryOnBuffering);
    }

    setupAudioControls() {
        const playBtn = document.getElementById('playBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const stopBtn = document.getElementById('stopBtn');
        const downloadBtn = document.getElementById('downloadBtn');
        const progressBar = document.getElementById('progressBar');
        const currentTimeEl = document.getElementById('currentTime');
        const totalTimeEl = document.getElementById('totalTime');

        // Reset UI for new audio
        if (progressBar) progressBar.style.width = '0%';
        if (currentTimeEl) currentTimeEl.textContent = '0:00';
        if (totalTimeEl) totalTimeEl.textContent = '0:00';

        if (!this.currentAudio) return;

        // Play button
        if (playBtn) {
            playBtn.onclick = () => {
                const p = this.currentAudio.play();
                if (p && typeof p.catch === 'function') {
                    p.catch(err => {
                        console.warn('Play error:', err);
                        this.showNotification('Unable to play audio. Check your system sound or permissions.', 'error');
                    });
                }
                this.speak('Playing audio');
            };
        }

        // Pause button
        if (pauseBtn) {
            pauseBtn.onclick = () => {
                this.currentAudio.pause();
                this.speak('Audio paused');
            };
        }

        // Stop button
        if (stopBtn) {
            stopBtn.onclick = () => {
                this.currentAudio.pause();
                this.currentAudio.currentTime = 0;
                this.speak('Audio stopped');
            };
        }

        // Download button
        if (downloadBtn) {
            downloadBtn.onclick = () => {
                const a = document.createElement('a');
                a.href = this.currentAudio.src;
                a.download = 'converted-audio.mp3';
                a.click();
                this.speak('Download started');
            };
        }

        // Progress bar
        this.currentAudio.addEventListener('timeupdate', () => {
            if (progressBar && this.currentAudio.duration) {
                const progress = (this.currentAudio.currentTime / this.currentAudio.duration) * 100;
                progressBar.style.width = `${progress}%`;
            }

            if (currentTimeEl) {
                currentTimeEl.textContent = this.formatTime(this.currentAudio.currentTime);
            }
        });

        this.currentAudio.addEventListener('loadedmetadata', () => {
            if (totalTimeEl) {
                totalTimeEl.textContent = this.formatTime(this.currentAudio.duration);
            }
        });

        this.currentAudio.addEventListener('ended', () => {
            if (progressBar) progressBar.style.width = '0%';
        });
    }

    // Utility Functions
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    showLoading(message) {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.querySelector('p').textContent = message;
            overlay.classList.add('show');
        }
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('show');
        }
    }

    showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        if (!notification) return;

        notification.textContent = message;
        notification.className = `notification ${type} show`;
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            this.hideNotification();
        }, 3000);

        // Speak notification
        this.speak(message);
    }

    hideNotification() {
        const notification = document.getElementById('notification');
        if (notification) {
            notification.classList.remove('show');
        }
    }
}

// Initialize VoiceBridge when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.voiceBridge = new VoiceBridge();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden && window.voiceBridge) {
        window.voiceBridge.stopSpeaking();
    }
});

// Handle beforeunload to clean up
window.addEventListener('beforeunload', () => {
    if (window.voiceBridge) {
        window.voiceBridge.stopSpeaking();
    }
});

#!/usr/bin/env python3
"""
VoiceBridge - Application Launcher
Simple launcher script for the VoiceBridge application
"""

import os
import sys
import subprocess
import webbrowser
import time
from pathlib import Path

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import flask
        import PyPDF2
        import pdfplumber
        import gtts
        print("✅ All dependencies are installed")
        return True
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("Please run: pip install -r requirements.txt")
        return False

def install_dependencies():
    """Install required dependencies"""
    print("Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def start_application():
    """Start the VoiceBridge application"""
    print("🚀 Starting VoiceBridge...")
    print("📱 The application will open in your default browser")
    print("🌐 If it doesn't open automatically, go to: http://localhost:5000")
    print("⏹️  Press Ctrl+C to stop the application")
    print("-" * 50)
    
    # Start the Flask app
    try:
        from app import app
        app.run(host='0.0.0.0', port=5000, debug=False)
    except KeyboardInterrupt:
        print("\n👋 VoiceBridge stopped. Thank you for using VoiceBridge!")
    except Exception as e:
        print(f"❌ Error starting application: {e}")

def main():
    """Main application launcher"""
    print("🎯 VoiceBridge - Text-to-Speech for Visually Impaired Students")
    print("=" * 60)
    
    # Check if we're in the right directory
    if not os.path.exists("app.py"):
        print("❌ Error: app.py not found in current directory")
        print("Please run this script from the VoiceBridge project directory")
        return
    
    # Check dependencies
    if not check_dependencies():
        print("\n🔧 Attempting to install missing dependencies...")
        if not install_dependencies():
            print("❌ Failed to install dependencies. Please install manually:")
            print("   pip install -r requirements.txt")
            return
    
    # Wait a moment then open browser
    def open_browser():
        time.sleep(2)
        webbrowser.open("http://localhost:5000")
    
    import threading
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()
    
    # Start the application
    start_application()

if __name__ == "__main__":
    main()

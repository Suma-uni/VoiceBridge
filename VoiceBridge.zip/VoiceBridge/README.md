# VoiceBridge - Text-to-Speech App for Visually Impaired Students

VoiceBridge is a comprehensive web application designed to help visually impaired students by providing text-to-speech functionality for both interface elements and document conversion.

## 🌟 Features

### Hover-to-Speak (UI Read-Aloud)
- **Automatic Interface Reading**: Hover over any button, link, or text element to hear it read aloud
- **Web Speech API Integration**: Uses browser's built-in speech synthesis for instant TTS
- **Customizable Settings**: Adjust voice speed, pitch, volume, and language
- **Keyboard Navigation**: Full keyboard support with Tab navigation and arrow keys

### File-to-Speech Conversion
- **Multi-format Support**: Upload .txt and .pdf files for conversion
- **Advanced PDF Processing**: Uses both PyPDF2 and pdfplumber for maximum compatibility
- **Audio Generation**: Converts extracted text to high-quality MP3 audio
- **Playback Controls**: Built-in audio player with play, pause, stop, and download options

### Accessibility Enhancements
- **Dark Mode & High Contrast**: Multiple visual themes for different vision needs
- **Adjustable Font Size**: Scalable text from 12px to 24px
- **Keyboard Navigation**: Complete keyboard accessibility
- **Screen Reader Support**: ARIA labels and semantic HTML structure
- **Focus Management**: Clear focus indicators and logical tab order

## 🚀 Quick Start

### Prerequisites
- Python 3.7 or higher
- Modern web browser with Web Speech API support
- Internet connection (for gTTS)

### Installation

1. **Clone or download the project files**

2. **Install Python dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the Flask backend**:
   ```bash
   python app.py
   ```

4. **Open the application**:
   - Navigate to `http://localhost:5000` in your web browser
   - The application will be ready to use!

## 📁 Project Structure

```
VoiceBridge/
├── index.html          # Main HTML file
├── styles.css          # CSS styles with themes
├── script.js           # JavaScript functionality
├── app.py              # Flask backend
├── requirements.txt    # Python dependencies
└── README.md           # This file
```

## 🎯 How to Use

### Hover-to-Speak Feature
1. **Enable Hover-to-Speak**: Go to Settings and ensure "Enable Hover-to-Speak" is checked
2. **Hover Over Elements**: Simply hover your mouse over any button, link, or text
3. **Keyboard Navigation**: Use Tab to navigate and focus on elements to hear them read
4. **Customize Voice**: Adjust rate, pitch, and volume in Settings

### File Conversion
1. **Upload Files**: Go to "File Converter" section
2. **Select Files**: Click the upload area or drag and drop .txt/.pdf files
3. **Convert**: Click "Convert to Speech" button
4. **Play Audio**: Use the built-in audio player to listen to your converted files
5. **Download**: Save the audio file to your device

### Accessibility Settings
1. **Font Size**: Adjust text size for better readability
2. **Dark Mode**: Toggle dark theme for reduced eye strain
3. **High Contrast**: Enable high contrast mode for better visibility
4. **Voice Settings**: Customize speech rate, pitch, and volume

## ⌨️ Keyboard Shortcuts

- **Tab**: Navigate to next element
- **Shift + Tab**: Navigate to previous element
- **Enter/Space**: Activate button or link
- **Arrow Keys**: Navigate through elements
- **Escape**: Stop speech or close dialogs

## 🔧 Technical Details

### Frontend Technologies
- **HTML5**: Semantic structure with ARIA labels
- **CSS3**: Modern styling with CSS variables for theming
- **JavaScript ES6+**: Class-based architecture with Web Speech API
- **Web Speech API**: Browser-native text-to-speech

### Backend Technologies
- **Flask**: Lightweight Python web framework
- **PyPDF2**: PDF text extraction
- **pdfplumber**: Advanced PDF processing
- **gTTS**: Google Text-to-Speech for file conversion
- **CORS**: Cross-origin resource sharing

### Supported File Formats
- **Text Files**: .txt (UTF-8, Latin-1 encoding)
- **PDF Files**: .pdf (text-based PDFs)

## 🌐 Browser Compatibility

### Required Features
- **Web Speech API**: Chrome, Edge, Safari, Firefox
- **File API**: All modern browsers
- **CSS Grid/Flexbox**: Modern browsers
- **ES6 Classes**: Modern browsers

### Recommended Browsers
- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

## 🎨 Themes and Customization

### Available Themes
1. **Light Mode**: Default bright theme
2. **Dark Mode**: Dark theme for low-light environments
3. **High Contrast**: High contrast theme for visual impairments

### Customization Options
- Font size (12px - 24px)
- Voice settings (rate, pitch, volume)
- Hover delay (100ms - 1000ms)
- Language selection

## 🔍 Troubleshooting

### Common Issues

**Hover-to-Speak not working**:
- Check if Web Speech API is supported in your browser
- Ensure "Enable Hover-to-Speak" is checked in Settings
- Try refreshing the page

**File conversion fails**:
- Check file format (.txt or .pdf only)
- Ensure file is not corrupted
- Try with a smaller file
- Check internet connection (required for gTTS)

**Audio not playing**:
- Check browser audio permissions
- Ensure audio file was generated successfully
- Try refreshing the page

### Browser-Specific Notes

**Chrome/Edge**: Full Web Speech API support
**Firefox**: Limited voice selection
**Safari**: May require user interaction for speech

## 🚀 Advanced Usage

### API Endpoints
- `GET /api/health`: Health check
- `POST /api/convert`: Convert files to speech
- `GET /api/voices`: Get available voices
- `POST /api/extract-text`: Extract text without conversion

### Configuration
- Maximum file size: 50MB
- Supported languages: English, Spanish, French, German, Italian, Portuguese, Russian, Japanese, Korean, Chinese
- Audio format: MP3

## 🤝 Contributing

This project is designed for accessibility and education. Contributions that improve accessibility features are especially welcome.

### Development Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Run development server: `python app.py`
3. Open browser to `http://localhost:5000`

## 📄 License

This project is created for educational purposes and accessibility. Feel free to use and modify for accessibility needs.

## 🎥 Demo Video

To see VoiceBridge in action:
1. Start the application
2. Navigate through different sections
3. Try hovering over elements to hear them read
4. Upload a text or PDF file and convert it to speech
5. Test the accessibility features like dark mode and keyboard navigation

## 🆘 Support

For issues or questions:
1. Check the troubleshooting section above
2. Ensure all dependencies are installed
3. Verify browser compatibility
4. Check console for error messages

---

**VoiceBridge - Making education accessible for all students** 🌟

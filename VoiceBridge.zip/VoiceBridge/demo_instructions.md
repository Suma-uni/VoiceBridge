# VoiceBridge Demo Instructions

## 🎯 Demo Overview
This document provides step-by-step instructions for demonstrating VoiceBridge's accessibility features and text-to-speech capabilities.

## 🚀 Getting Started

### 1. Launch the Application
```bash
# Option 1: Use the launcher script
python run.py

# Option 2: Manual start
python app.py
```

### 2. Open in Browser
- Navigate to `http://localhost:5000`
- The application should load with the home page

## 🎬 Demo Script

### Part 1: Hover-to-Speak Feature (2-3 minutes)

**Objective**: Demonstrate automatic interface reading

1. **Introduction**
   - "VoiceBridge helps visually impaired students by reading interface elements automatically"
   - "Let me show you the hover-to-speak feature"

2. **Demonstrate Hover-to-Speak**
   - Hover over the "VoiceBridge" title → Should read "VoiceBridge - Text to Speech Application"
   - Hover over navigation links → Should read each link's purpose
   - Hover over feature cards → Should read descriptions
   - Hover over buttons → Should read button labels

3. **Show Settings**
   - Navigate to Settings section
   - Show voice customization options
   - Demonstrate rate, pitch, and volume adjustments
   - Show accessibility settings (font size, dark mode, high contrast)

### Part 2: File Conversion Feature (3-4 minutes)

**Objective**: Demonstrate document-to-speech conversion

1. **Prepare Test Files**
   - Have a sample .txt file ready (create one with some text)
   - Have a sample .pdf file ready (text-based PDF)

2. **Upload and Convert**
   - Navigate to "File Converter" section
   - Click upload area or drag and drop files
   - Show file list with file details
   - Click "Convert to Speech" button
   - Wait for processing (show loading indicator)

3. **Audio Playback**
   - Demonstrate audio player controls
   - Play, pause, stop functionality
   - Show progress bar and time display
   - Demonstrate download feature

### Part 3: Accessibility Features (2-3 minutes)

**Objective**: Show accessibility enhancements

1. **Keyboard Navigation**
   - Press Tab to navigate through interface
   - Show focus indicators
   - Use Enter/Space to activate elements
   - Demonstrate arrow key navigation

2. **Visual Accessibility**
   - Toggle dark mode
   - Enable high contrast mode
   - Adjust font size
   - Show different themes

3. **Settings Customization**
   - Adjust hover delay
   - Change voice settings
   - Show language options

## 🎯 Key Points to Highlight

### Accessibility Features
- **Hover-to-Speak**: Automatic reading of interface elements
- **Keyboard Navigation**: Full keyboard accessibility
- **Visual Themes**: Dark mode and high contrast options
- **Customizable Settings**: Voice, font size, and interaction preferences

### Technical Capabilities
- **Multi-format Support**: .txt and .pdf files
- **Advanced PDF Processing**: Handles complex PDF layouts
- **High-quality Audio**: MP3 output with playback controls
- **Browser Integration**: Uses Web Speech API for instant feedback

### User Experience
- **Intuitive Interface**: Clean, accessible design
- **Responsive Design**: Works on different screen sizes
- **Error Handling**: Clear feedback for issues
- **Performance**: Fast processing and smooth interactions

## 🛠️ Demo Setup Checklist

### Before the Demo
- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Test the application: `python app.py`
- [ ] Prepare sample files (.txt and .pdf)
- [ ] Test audio output (speakers/headphones)
- [ ] Check browser compatibility
- [ ] Test hover-to-speak functionality

### During the Demo
- [ ] Speak clearly and explain each feature
- [ ] Show both mouse and keyboard interaction
- [ ] Demonstrate error handling (try invalid file)
- [ ] Show settings customization
- [ ] Highlight accessibility features
- [ ] Answer questions about technical implementation

### Demo Files to Prepare

**Sample Text File** (`sample.txt`):
```
Welcome to VoiceBridge!

This is a sample text file that demonstrates the text-to-speech conversion feature. 
The application can read this text aloud, making it accessible for visually impaired students.

Key features include:
- Hover-to-speak functionality
- File conversion capabilities
- Accessibility enhancements
- Customizable voice settings

Thank you for using VoiceBridge!
```

**Sample PDF File**: Create a simple PDF with text content for demonstration.

## 🎥 Recording Tips

### For Video Demo
1. **Screen Recording**: Use high resolution (1080p or higher)
2. **Audio Quality**: Use good microphone for narration
3. **Cursor Movement**: Move cursor slowly for hover demonstrations
4. **Full Screen**: Show full browser window
5. **Close Captions**: Consider adding captions for accessibility

### For Live Demo
1. **Preparation**: Test everything beforehand
2. **Backup Plan**: Have screenshots ready if technical issues occur
3. **Audience**: Adjust technical level based on audience
4. **Interaction**: Encourage questions and interaction
5. **Follow-up**: Provide contact information for further questions

## 🚨 Troubleshooting During Demo

### Common Issues and Solutions

**Hover-to-Speak not working**:
- Check browser permissions
- Refresh the page
- Check Settings → Enable Hover-to-Speak

**File conversion fails**:
- Check file format (.txt or .pdf only)
- Try smaller file size
- Check internet connection

**Audio not playing**:
- Check browser audio permissions
- Test with different browser
- Check system audio settings

**Slow performance**:
- Close other applications
- Use smaller test files
- Check internet connection

## 📝 Demo Script Variations

### For Technical Audience (5-7 minutes)
- Focus on implementation details
- Show code structure
- Discuss Web Speech API
- Explain PDF processing methods
- Cover accessibility standards

### For Educational Audience (3-5 minutes)
- Focus on learning benefits
- Emphasize accessibility features
- Show real-world use cases
- Highlight student-friendly design

### For Accessibility Audience (4-6 minutes)
- Deep dive into accessibility features
- Show keyboard navigation
- Demonstrate screen reader compatibility
- Test with different assistive technologies

## 🎯 Success Metrics

### Demo Success Indicators
- [ ] Hover-to-speak works smoothly
- [ ] File conversion completes successfully
- [ ] Audio playback is clear
- [ ] Keyboard navigation is intuitive
- [ ] Settings are easy to adjust
- [ ] Visual themes work properly

### Audience Engagement
- Questions about implementation
- Interest in accessibility features
- Requests for customization options
- Discussion of use cases
- Technical questions about integration

---

**Remember**: The goal is to show how VoiceBridge makes digital content accessible for visually impaired students through innovative text-to-speech technology and comprehensive accessibility features.

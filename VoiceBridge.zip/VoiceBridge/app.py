#!/usr/bin/env python3
"""
VoiceBridge - Flask Backend for Text-to-Speech Application
Handles file uploads, text extraction, and TTS conversion
"""

import os
import io
import tempfile
from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS
import PyPDF2
import pdfplumber
from gtts import gTTS
import logging
from werkzeug.utils import secure_filename
import mimetypes

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size
app.config['UPLOAD_FOLDER'] = tempfile.gettempdir()
ALLOWED_EXTENSIONS = {'txt', 'pdf'}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_pdf(file_path):
    """Extract text from PDF file using multiple methods for better compatibility"""
    text = ""
    
    try:
        # Method 1: Try pdfplumber first (better for complex layouts)
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        
        if text.strip():
            logger.info(f"Successfully extracted text using pdfplumber: {len(text)} characters")
            return text.strip()
            
    except Exception as e:
        logger.warning(f"pdfplumber failed: {e}")
    
    try:
        # Method 2: Fallback to PyPDF2
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        
        if text.strip():
            logger.info(f"Successfully extracted text using PyPDF2: {len(text)} characters")
            return text.strip()
            
    except Exception as e:
        logger.error(f"PyPDF2 also failed: {e}")
    
    return ""

def extract_text_from_txt(file_path):
    """Extract text from TXT file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
        logger.info(f"Successfully extracted text from TXT: {len(text)} characters")
        return text.strip()
    except UnicodeDecodeError:
        # Try with different encoding
        try:
            with open(file_path, 'r', encoding='latin-1') as file:
                text = file.read()
            logger.info(f"Successfully extracted text from TXT (latin-1): {len(text)} characters")
            return text.strip()
        except Exception as e:
            logger.error(f"Failed to read TXT file: {e}")
            return ""
    except Exception as e:
        logger.error(f"Error reading TXT file: {e}")
        return ""

def convert_text_to_speech(text, language='en', slow=False):
    """Convert text to speech using gTTS"""
    try:
        if not text.strip():
            raise ValueError("No text to convert")
        
        # Create gTTS object
        tts = gTTS(text=text, lang=language, slow=slow)
        
        # Save to temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
        tts.save(temp_file.name)
        
        logger.info(f"Successfully created audio file: {temp_file.name}")
        return temp_file.name
        
    except Exception as e:
        logger.error(f"Error converting text to speech: {e}")
        raise

@app.route('/')
def index():
    """Serve the main application"""
    return render_template('index.html')

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'message': 'VoiceBridge API is running',
        'version': '1.0.0'
    })

@app.route('/api/convert', methods=['POST'])
def convert_files():
    """Convert uploaded files to speech"""
    try:
        # Check if files were uploaded
        if 'files' not in request.files:
            return jsonify({'error': 'No files uploaded'}), 400
        
        files = request.files.getlist('files')
        if not files or all(file.filename == '' for file in files):
            return jsonify({'error': 'No files selected'}), 400
        
        # Validate files
        valid_files = []
        for file in files:
            if file and allowed_file(file.filename):
                valid_files.append(file)
            else:
                logger.warning(f"Invalid file: {file.filename}")
        
        if not valid_files:
            return jsonify({'error': 'No valid files uploaded'}), 400
        
        # Extract text from all files
        combined_text = ""
        temp_files = []
        
        for file in valid_files:
            try:
                # Save file temporarily
                filename = secure_filename(file.filename)
                temp_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(temp_path)
                temp_files.append(temp_path)
                
                # Extract text based on file type
                if filename.lower().endswith('.pdf'):
                    text = extract_text_from_pdf(temp_path)
                elif filename.lower().endswith('.txt'):
                    text = extract_text_from_txt(temp_path)
                else:
                    continue
                
                if text:
                    combined_text += f"\n\n--- {filename} ---\n\n{text}"
                    logger.info(f"Extracted {len(text)} characters from {filename}")
                else:
                    logger.warning(f"No text extracted from {filename}")
                    
            except Exception as e:
                logger.error(f"Error processing {file.filename}: {e}")
                continue
        
        # Check if we have any text to convert
        if not combined_text.strip():
            return jsonify({'error': 'No text could be extracted from the uploaded files'}), 400
        
        # Get language preference from request
        language = request.form.get('language', 'en')
        slow = request.form.get('slow', 'false').lower() == 'true'
        
        # Convert to speech
        audio_file_path = convert_text_to_speech(combined_text, language=language, slow=slow)
        
        # Clean up temporary files
        for temp_path in temp_files:
            try:
                os.unlink(temp_path)
            except Exception as e:
                logger.warning(f"Failed to delete temporary file {temp_path}: {e}")
        
        # Return audio file
        return send_file(
            audio_file_path,
            as_attachment=True,
            download_name='converted_audio.mp3',
            mimetype='audio/mpeg'
        )
        
    except Exception as e:
        logger.error(f"Error in convert_files: {e}")
        return jsonify({'error': f'Conversion failed: {str(e)}'}), 500

@app.route('/api/voices')
def get_voices():
    """Get available voices for TTS"""
    # This would typically return available voices from a TTS service
    # For now, return gTTS supported languages
    voices = [
        {'id': 'en', 'name': 'English', 'language': 'en'},
        {'id': 'es', 'name': 'Spanish', 'language': 'es'},
        {'id': 'fr', 'name': 'French', 'language': 'fr'},
        {'id': 'de', 'name': 'German', 'language': 'de'},
        {'id': 'it', 'name': 'Italian', 'language': 'it'},
        {'id': 'pt', 'name': 'Portuguese', 'language': 'pt'},
        {'id': 'ru', 'name': 'Russian', 'language': 'ru'},
        {'id': 'ja', 'name': 'Japanese', 'language': 'ja'},
        {'id': 'ko', 'name': 'Korean', 'language': 'ko'},
        {'id': 'zh', 'name': 'Chinese', 'language': 'zh'},
    ]
    return jsonify(voices)

@app.route('/api/extract-text', methods=['POST'])
def extract_text():
    """Extract text from uploaded files without converting to speech"""
    try:
        if 'files' not in request.files:
            return jsonify({'error': 'No files uploaded'}), 400
        
        files = request.files.getlist('files')
        if not files or all(file.filename == '' for file in files):
            return jsonify({'error': 'No files selected'}), 400
        
        extracted_texts = []
        
        for file in files:
            if file and allowed_file(file.filename):
                try:
                    # Save file temporarily
                    filename = secure_filename(file.filename)
                    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(temp_path)
                    
                    # Extract text
                    if filename.lower().endswith('.pdf'):
                        text = extract_text_from_pdf(temp_path)
                    elif filename.lower().endswith('.txt'):
                        text = extract_text_from_txt(temp_path)
                    else:
                        continue
                    
                    extracted_texts.append({
                        'filename': filename,
                        'text': text,
                        'length': len(text)
                    })
                    
                    # Clean up
                    os.unlink(temp_path)
                    
                except Exception as e:
                    logger.error(f"Error processing {file.filename}: {e}")
                    continue
        
        return jsonify({
            'success': True,
            'extracted_texts': extracted_texts,
            'total_files': len(extracted_texts)
        })
        
    except Exception as e:
        logger.error(f"Error in extract_text: {e}")
        return jsonify({'error': f'Text extraction failed: {str(e)}'}), 500

@app.errorhandler(413)
def too_large(e):
    """Handle file too large error"""
    return jsonify({'error': 'File too large. Maximum size is 50MB.'}), 413

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(e):
    """Handle 500 errors"""
    logger.error(f"Internal server error: {e}")
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Create upload directory if it doesn't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Run the Flask app
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )
